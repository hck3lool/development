#!/bin/bash
DEPENDENCIES_PACKAGES=(
"curl"
)