#!/bin/bash

cd /root/automated-tests
python run.py

