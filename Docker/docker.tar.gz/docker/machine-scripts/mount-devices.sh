#!/bin/bash

mkfs.ext3 /dev/sdb1
mkfs.ext3 /dev/sdc1

mkdir -p /media/A
mkdir -p /media/B

mount /dev/sdb1 /media/A
mount /dev/sdc1 /media/B