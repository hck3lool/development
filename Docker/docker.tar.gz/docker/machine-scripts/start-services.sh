#!/bin/bash
chmod 600 /root/.vnc/passwd && tightvncserver && ldtp && /bin/bash